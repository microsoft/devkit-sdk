// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. 

#include "HTS221Sensor.h"
#include "LIS2MDLSensor.h"
#include "RGB_LED.h"
#include "LSM6DSLSensor.h"
#include "LPS22HBSensor.h"
#include "IrDASensor.h"