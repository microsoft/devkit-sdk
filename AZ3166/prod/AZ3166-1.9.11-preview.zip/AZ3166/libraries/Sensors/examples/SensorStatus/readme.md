# Example: Sensor Status

In this project, you will learn how to connect to WiFi and check the status of all sensors for DevKit board.
The WiFi and sensor status will be shown on the screen when button A and B is clicked.

## Release Notes

### May 2017