# Example: Audio Example
In this project, you will learn how to use the embedded codec driver to record your voice, and you can also hear your audio from the headphone.

## Release Notes

### Nov 2017