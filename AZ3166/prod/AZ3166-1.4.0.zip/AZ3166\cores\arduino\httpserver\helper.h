// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. 

int httpd_get_tag_from_multipart_form(char *inbuf, char *boundary, const char *tag, char *val, unsigned val_len);
