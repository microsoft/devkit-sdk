// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef STRINGS_TYPES_H
#define STRINGS_TYPES_H

typedef struct STRING_TAG* STRING_HANDLE;

#endif  /*STRINGS_TYPES_H*/
