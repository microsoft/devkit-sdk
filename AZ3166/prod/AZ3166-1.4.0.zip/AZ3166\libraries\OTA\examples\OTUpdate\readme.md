# Example: OTA Example

In this project, you will learn how to upgrade firmware by providing a url of new firmware.

## Release Notes

### May 2018