# Example: Shake,Shake

In this project, you will learn how to use the motion sensor to trigger an event using Azure Functions. The app will retrieve a random tweet with a #hashtag you have configured in your Arduino sketch. The tweet will display on the DevKit screen, and every time you shake the DevKit board, you will get a new tweet.

## Release Notes

### May 2017