
/* Define to 1 if you have the <inttypes.h> header file. */
#undef JSON_C_HAVE_INTTYPES_H
