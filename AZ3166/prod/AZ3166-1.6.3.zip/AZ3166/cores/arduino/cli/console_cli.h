// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. 
 
#ifndef __CONSOLE_CLI_H__
#define __CONSOLE_CLI_H__

#ifdef __cplusplus
extern "C" {
#endif

void cli_main(void);

#ifdef __cplusplus
}
#endif

#endif