# Microsoft Azure IoT Hub demo

This sample demonstrates people how to send data from a device to Microsoft Azure by using mqtt API from Azure IoT C SDK.
Once you compile and upload this demo to your device, please press button A and then reset to enter the configuration mode, set the correct Wi-Fi SSI, Wi-Fi password and the Azure IoT hub connection string.